package com.example.payrollsystemgui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        if (Database.connect() != null) {
            System.out.println("DATABASE CONNECTED");
        } else {
            System.out.println("DATABASE FAILED");
        }

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 950, 750);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }
}
